A queen once asked her advisor, the grand vizier, why she never seemed able to
find mental contentment.  The vizier spoke to her, "Your
excellency, it is because your mind is constantly occupied with your
many exquisite possessions.  When your mind is absorbed with thoughts of
jewels, palaces, and gold it cannot find equilibrium."  The queen pondered
the vizier's words, and realized that he had spoken the truth.  She decided to
renounce her wealth and go live in the forest.  She passed
many years of simple living but still did not find inner peace.  One day
as she was gathering firewood she met the vizier on the road and told him of
her plight.  "My lady," he said, "even though you live simply, your mind still
hankers for your lost wealth.  Your mind is even more absorbed with riches
than before, and so you have not found peace."
